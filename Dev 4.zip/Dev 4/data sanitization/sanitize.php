<?php
	session_start();
	
	require('include/dbconnection_db.php');

		if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = sanitize_input($_POST["name"]);
  $email = sanitize_input($_POST["email"]);
  $website = sanitize_input($_POST["website"]);
  $comment = sanitize_input($_POST["comment"]);
  $gender = sanitize_input($_POST["gender"]);
}
///Using php fucntions
function sanitize_input($data) {

  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;

}