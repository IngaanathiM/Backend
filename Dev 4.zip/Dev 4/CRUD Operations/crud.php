<?php
class Data {

require("includes/dbconnection.php");

private $_mysqli;

object
public function __construct($mysqli=NULL) {
$this->_mysqli = $mysqli;
}


public function createData() {

}

public function readAllData() {


}

public function readDataItem() {

}

public function updateData() {

}
public function deleteData() {

}
}
?>