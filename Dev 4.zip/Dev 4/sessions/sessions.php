<?php
	require('include/dbconnection.php');

	session_start();
	
	if (isset($_POST['logout'])) {
		session_destroy();
		header('Location:index.php');
	}
	
	elseif($_SESSION['login']=="admin")
	{
		$user =$_SESSION['user'];

		if(isset($_SESSION['message']))
		{	
			echo '<script type="text/javascript">alert("'.$_SESSION['message'].'");</script>';
			unset($_SESSION["message"]); 
		}
		
	}
	else
		header('Location:index.php');		

?>
